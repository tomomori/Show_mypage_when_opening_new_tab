# Show_mypage_when_opening_new_tab

Show my page when you open a new tab in your browser

Microsoft's Edge browser shows bing.com when you open a new tab.
When I open a new tab, I want to open my homepage, company homepage, google, etc.
I created an extension for that.

マイクロソフトのEdgeブラウザは、新しいタブを開いたとき、bing.comを表示する。
新しいタブを開いたときは、自分のホームページや会社のホームページまたはgoogle等を開きたい。
そのために拡張機能を作成した。
